# Priority recheck, 14 October 2026, 03:00–03:20 UTC

Question: before this work, had anyone refuted Sahbi's Conjecture 4.1 (β_k = SF_k on bipartite
graphs) for some k ≥ 3, answered his Problem 7.3 (β_3 = SF_3 on triangle-free graphs?), or proved
his Conjecture 6.4 (β_k = SF_k on chain graphs for k ≥ 3), all from arXiv:2610.03785?

| Source | Search | Result |
|---|---|---|
| OpenRefute (the-omega-institute/trureturing) | issues and pull requests mentioning `2610.03785` | only issue #14706 and pull request #14727 (9 October 2026, k = 2 only; cited in the paper as theirs) |
| arXiv | abstract page of 2610.03785 | still v2 (6 October 2026); the abstract keeps the chain-graph case open for k ≥ 3 |
| Zenodo | `"star-forming" AND "independence"`, newest first | nothing on k-star-forming sets in graphs (astronomy and unrelated records only) |
| Web search | "star-forming" with "chain graph", k-independence, Sahbi | nothing on k-star-forming sets in chain graphs |

The full check of 02:10–02:40 UTC (OpenRefute, arXiv full-text search, Zenodo, zbMATH, web) is
`repository/PRIORITY-CHECK.md`. Nothing found answers any of the three questions before this work.
The full text of Chellali and Favaron (2009), which introduced SF_k, was not available; its zbMATH
summary does not mention bipartite or chain graphs, and Sahbi, who cites it, poses the questions as
open.
