# Priority rechecks, 14 October 2026

## 03:00–03:20 UTC: Conjecture 4.1 (k ≥ 3), Problem 7.3, Conjecture 6.4

Question: before this work, had anyone refuted Sahbi's Conjecture 4.1 (β_k = SF_k on bipartite
graphs) for some k ≥ 3, answered his Problem 7.3 (β_3 = SF_3 on triangle-free graphs?), or proved
his Conjecture 6.4 (β_k = SF_k on chain graphs for k ≥ 3), all from arXiv:2610.03785?

| Source | Search | Result |
|---|---|---|
| OpenRefute (the-omega-institute/trureturing) | issues and pull requests mentioning `2610.03785` | only issue #14706 and pull request #14727 (9 October 2026, k = 2 only; cited in the paper as theirs) |
| arXiv | abstract page of 2610.03785 | read as v2 (6 October 2026); in fact v3, a withdrawal, had been posted on 12 October (see below) |
| Zenodo | `"star-forming" AND "independence"`, newest first | nothing on k-star-forming sets in graphs (astronomy and unrelated records only) |
| Web search | "star-forming" with "chain graph", k-independence, Sahbi | nothing on k-star-forming sets in chain graphs |

## 06:20–06:30 UTC: Problem 9.3 and the withdrawal

| Source | Search | Result |
|---|---|---|
| arXiv | abstract page of 2610.03785 | v1 30 Sep, v2 6 Oct, v3 12 Oct 2026 20:05 UTC: withdrawn by the author, comment "Some conjectures in this paper have been disproved". The paper cites v2. |
| OpenRefute | pull requests mentioning `2610.03785`; issues on star-forming sets, NP-completeness, Sahbi | still only #14706 and #14727; nothing on Problem 9.3 |
| arXiv | abstracts containing "star-forming" in math.CO | only Sahbi's paper |
| Zenodo | "star-forming" with Sahbi, k-independence or dissociation | only this repository's v1.0.0 record |
| Web search | "star-forming" set, NP-complete, bipartite | nothing on k-star-forming sets |

Known and cited: β_2 (the dissociation number) is NP-hard on bipartite graphs (Yannakakis 1981);
Independent Set is NP-complete (Karp 1972), also on planar graphs (Garey, Johnson and Stockmeyer
1976). These concern β_2 and α, not SF_2.

The full checks are `repository/PRIORITY-CHECK.md`. Nothing found answers any of the four questions
before this work. The full text of Chellali and Favaron (2009), which introduced SF_k, was not
available; its zbMATH summary does not mention bipartite or chain graphs or complexity, and Sahbi,
who cites it, poses the questions as open.
