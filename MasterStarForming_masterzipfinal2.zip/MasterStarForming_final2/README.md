# Master zip: k-star-forming sets and k-independence in bipartite graphs (final2)

Built 14 October 2026, 03:25 UTC, from creelie/Conjecture-002, main at 4ab229b (release v1.0.0 with its DOI
recorded).

- Paper: "Upper k-star-forming sets and k-independence in bipartite graphs", Deep Bhattacharjee
  (sole author).
- DOI of release v1.0.0: [10.5281/zenodo.23356026](https://doi.org/10.5281/zenodo.23356026); all versions:
  [10.5281/zenodo.23356025](https://doi.org/10.5281/zenodo.23356025).
- Target journal: *Discrete Mathematics* (Elsevier), which published the theorem Γ = α for
  bipartite graphs (Cockayne, Favaron, Payan and Thomason, 1981) that the conjecture generalises.
  Fallbacks: *Discussiones Mathematicae Graph Theory*; *Graphs and Combinatorics*.

## What is proved

R. Sahbi, *Upper k-star-forming sets, k-independence, and upper domination* (arXiv:2610.03785,
v2 6 October 2026), conjectured that the k-independence number β_k and the upper
k-star-forming number SF_k agree on every bipartite graph (Conjecture 4.1), conjectured the same
for chain graphs and k ≥ 3 (Conjecture 6.4, Problem 9.1), and asked whether β_3 = SF_3 on
triangle-free graphs (Problem 7.3). Only the case k = 2 of Conjecture 4.1 had been refuted, by a
10-vertex graph (the-omega-institute/trureturing, pull request 14727), which the paper cites as
theirs.

1. **Conjecture 4.1 is false for every k ≥ 3, and the answer to Problem 7.3 is no.** The
   connected bipartite graph G_k on 3k + 3 vertices has β_k = 2k + 2 and a minimal
   k-star-forming set of size 3k.
2. **Conjecture 6.4 is true for every k ≥ 2**: β_k = SF_k on every chain graph.

Both are proved by hand in the paper and formalised in Lean 4 with Mathlib, with Sahbi's
definitions taken literally (`StarForming.betaK_lt_sfK`, `StarForming.sfK_eq_betaK_of_isChain`;
eighteen theorems audited, standard axioms only). Independent C and Python programs recheck the
numbers of G_k for k = 2..7 and the chain-graph lemmas on every chain graph with at most 12
vertices. These are full, unconditional answers.

## What is open

- Sahbi's grid conjectures (8.4, 8.5) and Problem 9.3 (the complexity of SF_2 on bipartite
  graphs) are not touched.
- Problem 9.4 for triangle-free classes other than the bipartite graphs.

## Contents

| Path | What it is |
| --- | --- |
| `journal-DiscreteMathematics/dm-manuscript-final2.pdf` | Manuscript in Elsevier's class (elsarticle), 9 pages, with the declarations |
| `journal-DiscreteMathematics/dm-manuscript-source-final2.zip` | Its LaTeX source and PNG figure (compiles with pdflatex) |
| `journal-DiscreteMathematics/cover-letter.md` | Cover letter |
| `journal-DiscreteMathematics/submission-checklist.md` | Submission steps and what only the author can confirm |
| `preprint/star-forming-bipartite_final2.pdf` | The preprint (amsart), as released |
| `preprint/star-forming-bipartite_final2-tex.zip` | Its LaTeX source with the PNG figure |
| `preprint/star-forming-bipartite_final2-arxiv.tar.gz` | The arXiv upload |
| `PRIORITY-RECHECK-2026-10-14.md` | Priority recheck on 14 October 2026 |
| `repository/` | The repository at 4ab229b: Lean proofs, C and Python checks, searches, the full priority check |

## Before submitting

The manuscript states no funding and no competing interests; please confirm both. The submission
system may ask for a postal address and telephone number. See
`journal-DiscreteMathematics/submission-checklist.md`.
