# Cover letter

To the Editors of *Discrete Mathematics*

Dear Editors,

I submit the manuscript "Upper k-star-forming sets and k-independence in bipartite graphs" for
consideration as a note.

Chellali and Favaron (J. Combin. Math. Combin. Comput. 68 (2009)) introduced k-star-forming sets and
proved that the k-independence number β_k never exceeds the upper k-star-forming number SF_k. For
k = 1 these are the independence number and the upper domination number, which agree on bipartite
graphs by the theorem of Cockayne, Favaron, Payan and Thomason (Discrete Math. 33 (1981)). Sahbi
(arXiv:2610.03785, 2026) conjectured that β_k = SF_k on bipartite graphs for every k, and in
particular on chain graphs, and asked whether β_3 = SF_3 on triangle-free graphs. A ten-vertex
bipartite graph posted publicly in October 2026 refutes the case k = 2.

The manuscript shows that the conjecture fails for every k ≥ 3: an explicit connected bipartite
graph on 3k + 3 vertices has β_k = 2k + 2 and a minimal k-star-forming set of size 3k. This answers
Sahbi's question on triangle-free graphs in the negative, and shows that among bipartite graphs the
equality holds for all graphs only when k = 1. On the other hand, it proves Sahbi's conjecture that
β_k = SF_k on chain graphs for every k ≥ 3 (he proved k = 2). Both proofs are short and by hand;
they are also formalised in Lean 4 with Mathlib, and the Lean development and the search programs
are publicly archived (see Data availability).

The manuscript is not under consideration elsewhere. It has not been published; a preprint is
archived on Zenodo with the repository. There is no funding to declare and no competing interest.

Suggested area: graph theory (domination and independence).

Yours sincerely,

Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
d.bhattacharjee@erl-forschung.de · itsdeep@live.com · ORCID 0000-0003-0466-750X
