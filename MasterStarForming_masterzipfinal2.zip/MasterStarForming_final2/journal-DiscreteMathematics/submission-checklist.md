# Submission checklist: Discrete Mathematics

Journal: *Discrete Mathematics* (Elsevier), which publishes short notes and published the
theorem Γ = α for bipartite graphs (Cockayne, Favaron, Payan and Thomason, 1981) that the
conjecture generalises. Submission through Elsevier's Editorial Manager, linked from
https://www.sciencedirect.com/journal/discrete-mathematics. Fallbacks: *Discussiones Mathematicae
Graph Theory*; *Graphs and Combinatorics*.

Files to upload:

1. `dm-manuscript-final2.pdf`: the manuscript in Elsevier's class `elsarticle` (9 pages).
2. `dm-manuscript-source-final2.zip`: `main.tex` and the PNG figure; it compiles with
   `pdflatex main.tex` (three runs) on any TeX Live with `elsarticle`.
3. `cover-letter.md`: paste into the cover-letter field.

Metadata to enter:

- Title: Upper k-star-forming sets and k-independence in bipartite graphs
- Article type: Note if the system offers it, otherwise Research paper
- Author: Deep Bhattacharjee (sole author, corresponding), ORCID 0000-0003-0466-750X
- Affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar,
  Odisha 751030, India
- Keywords: k-independence; k-star-forming set; upper domination; bipartite graph; chain graph;
  formal verification
- MSC 2020: 05C69

Only the author can confirm:

- [ ] "This research did not receive any specific grant ..." (stated under Funding)
- [ ] "The author has no competing interests to declare." (stated under Declaration of competing
      interest)
- [ ] postal address and telephone number, if the system asks for them
- [ ] suggested referees, if the system asks (people who work on k-independence or domination and
      are not coauthors of the author)

Before submitting, optionally post the arXiv tarball (`preprint/star-forming-bipartite_final2-arxiv.tar.gz`)
to arXiv (math.CO); the journal does not require it.
